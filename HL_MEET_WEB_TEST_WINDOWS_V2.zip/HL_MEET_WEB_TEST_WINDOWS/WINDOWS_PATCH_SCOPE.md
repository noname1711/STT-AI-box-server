# Windows test patch scope

This package was derived from the supplied `web.zip`.

## Intentionally changed

- `index.html`: Windows/backend connection guidance only.
- `app.js`: backend normalization, persistence, launcher query support, auto-connect, and clearer connection errors/timeouts.
- `app.css`: backend-status styling only.
- `README.md`: Windows one-click instructions.
- Added `START_WINDOWS_TEST.bat`, `windows-test-server.ps1`, and `WINDOWS_TEST_GUIDE.txt`.

## Intentionally unchanged audio path

`pcm-worklet.js` is byte-for-byte unchanged from the uploaded source.

- original pcm-worklet.js SHA256: `a12275b4468b9e100f0376473539b78a3b2fc20d73e9c39e6904976f795472ea`
- Windows package pcm-worklet.js SHA256: `a12275b4468b9e100f0376473539b78a3b2fc20d73e9c39e6904976f795472ea`

The diff does not alter `startCapture`, PCM16 framing, Vietnamese native-16k fail-closed behavior, Phase6G VI tail flush, WebSocket PCM send behavior, transcript handling, or translation semantics.

## Source hashes

- original app.js: `7e2747c0f43619afe15cc94d9f149a23c1b150dc08e75c1a05a53a9850ff2a91`
- modified app.js: `8746aafded7200bc6bdd3f576fd7f942603b7a8e23ae77b7ae60e6293d91b77d`
- original index.html: `1b7a24e3c2fecc66bc822a2b6cbdb1f09c081cb659ea16532341a8285bc514c8`
- modified index.html: `ea039b8f93156198a1a19ff7b8315328b2287b0862541fa0e99b2faf73cce1be`
- original app.css: `e885a3481f1f18a4219c70a65930ac1fc102dc505ff8da6702e87bdd4e797f44`
- modified app.css: `d6c81e01d32bb34e1fd54f6f745535a64fa4ddc62d75c9ceac4f6ae8947c5453`
