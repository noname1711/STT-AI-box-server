$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Port = 8000
$BackendPort = 8080
$CacheDir = Join-Path $env:LOCALAPPDATA "HLMeetWebTest"
$LastBoxFile = Join-Path $CacheDir "last-ai-box.txt"

function Write-Step([string]$Text) {
    Write-Host "[HL Meet] $Text" -ForegroundColor Cyan
}

function Write-Good([string]$Text) {
    Write-Host "[HL Meet] $Text" -ForegroundColor Green
}

function Write-Warn([string]$Text) {
    Write-Host "[HL Meet] $Text" -ForegroundColor Yellow
}

function Test-PrivateIPv4([string]$Address) {
    return (
        $Address -match '^10\.' -or
        $Address -match '^192\.168\.' -or
        $Address -match '^172\.(1[6-9]|2[0-9]|3[01])\.'
    )
}

function Convert-IPv4ToNumber([string]$Address) {
    $p = $Address.Split('.')
    if ($p.Count -ne 4) { throw "Invalid IPv4 address: $Address" }
    return [uint64]([uint64][int]$p[0] * 16777216 +
                    [uint64][int]$p[1] * 65536 +
                    [uint64][int]$p[2] * 256 +
                    [uint64][int]$p[3])
}

function Convert-NumberToIPv4([uint64]$Value) {
    $a = [math]::Floor($Value / 16777216) % 256
    $b = [math]::Floor($Value / 65536) % 256
    $c = [math]::Floor($Value / 256) % 256
    $d = $Value % 256
    return "$([int]$a).$([int]$b).$([int]$c).$([int]$d)"
}

function Get-NetworkInfo([string]$Address, [int]$PrefixLength) {
    if ($PrefixLength -lt 1 -or $PrefixLength -gt 32) { return $null }

    $ipNumber = Convert-IPv4ToNumber $Address
    $blockSize = [uint64][math]::Pow(2, (32 - $PrefixLength))
    $networkNumber = [uint64]([math]::Floor($ipNumber / $blockSize) * $blockSize)
    $broadcastNumber = [uint64]($networkNumber + $blockSize - 1)

    return [PSCustomObject]@{
        Address = $Address
        PrefixLength = $PrefixLength
        Network = (Convert-NumberToIPv4 $networkNumber)
        NetworkNumber = $networkNumber
        BroadcastNumber = $broadcastNumber
        HostCount = [uint64][math]::Max(0, ([double]$blockSize - 2))
    }
}

function Test-HLMeetEndpoint([string]$Address) {
    if ([string]::IsNullOrWhiteSpace($Address)) { return $false }

    try {
        $url = "http://${Address}:$BackendPort/api/health"
        $request = [System.Net.HttpWebRequest]::Create($url)
        $request.Method = "GET"
        $request.Timeout = 1800
        $request.ReadWriteTimeout = 1800
        $request.Proxy = $null
        $request.KeepAlive = $false

        $response = $request.GetResponse()
        try {
            if ([int]$response.StatusCode -ne 200) { return $false }
            $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
            try {
                $body = $reader.ReadToEnd()
            } finally {
                $reader.Dispose()
            }
        } finally {
            $response.Dispose()
        }

        try {
            $json = $body | ConvertFrom-Json
        } catch {
            return $false
        }

        if ($null -eq $json) { return $false }

        # Accept the known HL Meet health metadata across release revisions.
        $names = @($json.PSObject.Properties.Name)
        foreach ($key in @(
            'version', 'app_version', 'ready', 'queue', 'stt_engine',
            'protocol', 'protocol_version', 'clients', 'requests',
            'stream_segments', 'translation', 'models'
        )) {
            if ($names -contains $key) { return $true }
        }

        return $false
    } catch {
        return $false
    }
}

function Resolve-HLMeetMdns {
    try {
        $ips = [System.Net.Dns]::GetHostAddresses('meeting-server.local') |
            Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork }

        foreach ($ip in $ips) {
            $text = $ip.IPAddressToString
            if (Test-HLMeetEndpoint $text) { return $text }
        }
    } catch {}

    return $null
}

function Find-HLMeetNeighbors {
    Write-Step "Checking devices already visible to Windows ..."

    try {
        $candidates = Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object {
                $_.IPAddress -and
                (Test-PrivateIPv4 ([string]$_.IPAddress)) -and
                $_.State -notin @('Unreachable', 'Incomplete')
            } |
            Select-Object -ExpandProperty IPAddress -Unique

        foreach ($candidate in $candidates) {
            if (Test-HLMeetEndpoint ([string]$candidate)) {
                return [string]$candidate
            }
        }
    } catch {}

    return $null
}

function Get-PreferredNetworkRanges {
    $result = New-Object System.Collections.ArrayList
    $seen = @{}

    try {
        $configs = @(Get-NetIPConfiguration -ErrorAction Stop | Where-Object {
            $_.NetAdapter -and
            $_.NetAdapter.Status -eq 'Up' -and
            $_.IPv4Address
        })

        # Prefer interfaces that actually have a default gateway. This avoids
        # scanning WSL/Hyper-V/Docker/VPN adapters before the real Wi-Fi/LAN.
        $ordered = @($configs | Sort-Object -Property @(
            @{ Expression = { if ($_.IPv4DefaultGateway) { 0 } else { 1 } } },
            @{ Expression = { [string]$_.InterfaceAlias } }
        ))

        foreach ($config in $ordered) {
            $hasGateway = [bool]$config.IPv4DefaultGateway

            # Only fall back to no-gateway/virtual interfaces when no routed
            # private LAN has been collected yet.
            if (-not $hasGateway -and $result.Count -gt 0) { continue }

            foreach ($entry in @($config.IPv4Address)) {
                $ip = [string]$entry.IPAddress
                $prefixLength = [int]$entry.PrefixLength

                if (-not (Test-PrivateIPv4 $ip)) { continue }

                $net = Get-NetworkInfo $ip $prefixLength
                if ($null -eq $net) { continue }

                $key = "$($net.Network)/$prefixLength"
                if ($seen.ContainsKey($key)) { continue }
                $seen[$key] = $true

                [void]$result.Add([PSCustomObject]@{
                    InterfaceAlias = [string]$config.InterfaceAlias
                    Address = $ip
                    PrefixLength = $prefixLength
                    Network = $net.Network
                    NetworkNumber = $net.NetworkNumber
                    BroadcastNumber = $net.BroadcastNumber
                    HostCount = $net.HostCount
                    HasGateway = $hasGateway
                })
            }
        }
    } catch {}

    return @($result)
}

function Find-HLMeetInAddressBatch([string[]]$Addresses) {
    $probes = New-Object System.Collections.ArrayList

    foreach ($hostAddress in $Addresses) {
        $client = New-Object System.Net.Sockets.TcpClient
        try {
            $async = $client.BeginConnect($hostAddress, $BackendPort, $null, $null)
            [void]$probes.Add([PSCustomObject]@{
                Address = $hostAddress
                Client = $client
                Async = $async
            })
        } catch {
            try { $client.Dispose() } catch {}
        }
    }

    $found = $null

    foreach ($probe in $probes) {
        $open = $false
        try {
            if ($probe.Async.AsyncWaitHandle.WaitOne(700, $false)) {
                $probe.Client.EndConnect($probe.Async)
                $open = $probe.Client.Connected
            }
        } catch {
            $open = $false
        } finally {
            try { $probe.Async.AsyncWaitHandle.Close() } catch {}
            try { $probe.Client.Close() } catch {}
            try { $probe.Client.Dispose() } catch {}
        }

        if (-not $found -and $open) {
            if (Test-HLMeetEndpoint $probe.Address) {
                $found = $probe.Address
            }
        }
    }

    return $found
}

function Find-HLMeetInRange($Range) {
    $prefix = [int]$Range.PrefixLength
    $hostCount = [uint64]$Range.HostCount

    # Full scan is safe for normal Wi-Fi/LAN ranges up to /20 (4094 hosts).
    # For a very large enterprise subnet, probe only the local /24 after the
    # neighbor/mDNS fast paths; a manual IP remains available as fallback.
    if ($prefix -lt 20) {
        Write-Warn "LAN $($Range.Network)/$prefix is very large. Scanning the local /24 first."
        $parts = $Range.Address.Split('.')
        $local24 = "$($parts[0]).$($parts[1]).$($parts[2])"
        $addresses = @()
        for ($i = 1; $i -le 254; $i++) { $addresses += "$local24.$i" }

        for ($offset = 0; $offset -lt $addresses.Count; $offset += 64) {
            $end = [math]::Min($offset + 63, $addresses.Count - 1)
            $batch = @($addresses[$offset..$end])
            $found = Find-HLMeetInAddressBatch $batch
            if ($found) { return $found }
        }
        return $null
    }

    Write-Step "Windows LAN: $($Range.Address)/$prefix on $($Range.InterfaceAlias)"
    Write-Step "Scanning actual subnet $($Range.Network)/$prefix ($hostCount possible hosts) for AI Box ..."

    $batch = New-Object System.Collections.Generic.List[string]

    $start = [uint64]($Range.NetworkNumber + 1)
    $end = [uint64]($Range.BroadcastNumber - 1)

    for ($n = $start; $n -le $end; $n++) {
        $addr = Convert-NumberToIPv4 $n
        if ($addr -eq $Range.Address) { continue }
        $batch.Add($addr)

        if ($batch.Count -ge 64) {
            $found = Find-HLMeetInAddressBatch @($batch.ToArray())
            if ($found) { return $found }
            $batch.Clear()
        }
    }

    if ($batch.Count -gt 0) {
        $found = Find-HLMeetInAddressBatch @($batch.ToArray())
        if ($found) { return $found }
    }

    return $null
}

function Find-HLMeetBox {
    # Fast path 1: reuse the last confirmed address.
    try {
        if (Test-Path $LastBoxFile) {
            $last = (Get-Content $LastBoxFile -Raw).Trim()
            if ($last -and (Test-HLMeetEndpoint $last)) {
                Write-Good "Found previous AI Box at $last"
                return $last
            }
        }
    } catch {}

    # Fast path 2: mDNS when Windows resolves .local on this installation.
    Write-Step "Trying meeting-server.local ..."
    $mdns = Resolve-HLMeetMdns
    if ($mdns) {
        Write-Good "Found AI Box through meeting-server.local: $mdns"
        return $mdns
    }

    # Fast path 3: devices already known to the Windows neighbor/ARP table.
    $neighbor = Find-HLMeetNeighbors
    if ($neighbor) {
        Write-Good "Found AI Box from Windows network table: $neighbor"
        return $neighbor
    }

    # Full path: respect Windows PrefixLength. The previous launcher assumed
    # /24 and could miss e.g. a Jetson at 192.168.0.x when Windows was
    # 192.168.1.x/23. This scan covers the actual routed LAN range.
    $ranges = Get-PreferredNetworkRanges
    foreach ($range in $ranges) {
        $found = Find-HLMeetInRange $range
        if ($found) {
            Write-Good "Found AI Box: $found"
            return $found
        }
    }

    return $null
}

function Get-ContentType([string]$Path) {
    switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        '.html' { return 'text/html; charset=utf-8' }
        '.htm'  { return 'text/html; charset=utf-8' }
        '.js'   { return 'text/javascript; charset=utf-8' }
        '.mjs'  { return 'text/javascript; charset=utf-8' }
        '.css'  { return 'text/css; charset=utf-8' }
        '.json' { return 'application/json; charset=utf-8' }
        '.txt'  { return 'text/plain; charset=utf-8' }
        '.md'   { return 'text/plain; charset=utf-8' }
        '.svg'  { return 'image/svg+xml' }
        '.png'  { return 'image/png' }
        '.jpg'  { return 'image/jpeg' }
        '.jpeg' { return 'image/jpeg' }
        '.ico'  { return 'image/x-icon' }
        '.wav'  { return 'audio/wav' }
        default { return 'application/octet-stream' }
    }
}

function Write-HttpResponse {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$StatusCode,
        [string]$StatusText,
        [byte[]]$Body,
        [string]$ContentType
    )

    if ($null -eq $Body) { $Body = [byte[]]@() }
    $header = "HTTP/1.1 $StatusCode $StatusText`r`n" +
              "Content-Type: $ContentType`r`n" +
              "Content-Length: $($Body.Length)`r`n" +
              "Cache-Control: no-store, no-cache, must-revalidate`r`n" +
              "Pragma: no-cache`r`n" +
              "Connection: close`r`n`r`n"

    $headBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headBytes, 0, $headBytes.Length)

    if ($Body.Length -gt 0) {
        $Stream.Write($Body, 0, $Body.Length)
    }

    $Stream.Flush()
}

function Start-LocalStaticServer([string]$Backend) {
    $loopback = [System.Net.IPAddress]::Parse('127.0.0.1')
    $listener = New-Object System.Net.Sockets.TcpListener($loopback, $Port)

    try {
        $listener.Start()
    } catch {
        Write-Warn "Cannot start localhost:$Port. Close any old web test/server using port $Port and run START_WINDOWS_TEST.bat again."
        return 30
    }

    $encodedBackend = [System.Uri]::EscapeDataString($Backend)
    $launchUrl = "http://localhost:$Port/?backend=$encodedBackend&autoconnect=1"

    Write-Good "AI Box backend = $Backend"
    Write-Good "Web test       = http://localhost:$Port"
    Write-Host ""
    Write-Host "Browser is opening. When the page says Connected, click Start microphone." -ForegroundColor White
    Write-Host "Allow microphone access when Windows/browser asks." -ForegroundColor White
    Write-Host "KEEP THIS WINDOW OPEN WHILE TESTING. Press Ctrl+C here when finished." -ForegroundColor Yellow
    Write-Host ""

    Start-Process $launchUrl

    $rootFull = [System.IO.Path]::GetFullPath($Root)
    if (-not $rootFull.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $rootFull += [System.IO.Path]::DirectorySeparatorChar
    }

    try {
        while ($true) {
            $client = $listener.AcceptTcpClient()
            try {
                $stream = $client.GetStream()
                $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)

                try {
                    $requestLine = $reader.ReadLine()
                    if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }

                    while ($true) {
                        $line = $reader.ReadLine()
                        if ($null -eq $line -or $line -eq '') { break }
                    }

                    $parts = $requestLine.Split(' ')
                    if ($parts.Count -lt 2 -or $parts[0] -ne 'GET') {
                        $body = [System.Text.Encoding]::UTF8.GetBytes('Method Not Allowed')
                        Write-HttpResponse $stream 405 'Method Not Allowed' $body 'text/plain; charset=utf-8'
                        continue
                    }

                    $uri = New-Object System.Uri("http://localhost:$Port$($parts[1])")
                    $relative = [System.Uri]::UnescapeDataString($uri.AbsolutePath.TrimStart('/'))
                    if ([string]::IsNullOrWhiteSpace($relative)) { $relative = 'index.html' }
                    $relative = $relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar)

                    $full = [System.IO.Path]::GetFullPath((Join-Path $Root $relative))
                    if (-not $full.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                        $body = [System.Text.Encoding]::UTF8.GetBytes('Forbidden')
                        Write-HttpResponse $stream 403 'Forbidden' $body 'text/plain; charset=utf-8'
                        continue
                    }

                    if (-not (Test-Path $full -PathType Leaf)) {
                        $body = [System.Text.Encoding]::UTF8.GetBytes('Not Found')
                        Write-HttpResponse $stream 404 'Not Found' $body 'text/plain; charset=utf-8'
                        continue
                    }

                    $bytes = [System.IO.File]::ReadAllBytes($full)
                    $contentType = Get-ContentType $full
                    Write-HttpResponse $stream 200 'OK' $bytes $contentType
                } finally {
                    $reader.Dispose()
                }
            } catch {
                # Browsers can cancel speculative requests. Keep serving.
            } finally {
                try { $client.Close() } catch {}
                try { $client.Dispose() } catch {}
            }
        }
    } finally {
        try { $listener.Stop() } catch {}
    }

    return 0
}

Write-Host "===============================================" -ForegroundColor White
Write-Host "    HL MEET WINDOWS WEB TEST LAUNCHER V2" -ForegroundColor White
Write-Host "===============================================" -ForegroundColor White
Write-Host ""

if (-not (Test-Path (Join-Path $Root 'index.html'))) {
    Write-Warn "index.html is missing from this folder."
    exit 10
}

Write-Step "Looking for AI Box. No SSH is required."
$box = Find-HLMeetBox

if (-not $box) {
    Write-Warn "AI Box was not found automatically."
    Write-Host "Make sure the Windows laptop and AI Box are on the same Wi-Fi/LAN." -ForegroundColor White
    Write-Host "If you know the AI Box IP, type only the IP below. Otherwise press Enter to stop." -ForegroundColor White
    $manual = (Read-Host "AI Box IP").Trim()

    if (-not $manual) {
        exit 20
    }

    $manual = $manual -replace '^https?://', ''
    $manual = $manual -replace ':8080/?$', ''

    if (-not (Test-HLMeetEndpoint $manual)) {
        Write-Warn "No HL Meet health response at http://${manual}:$BackendPort/api/health"
        exit 21
    }

    $box = $manual
}

try {
    New-Item -ItemType Directory -Force -Path $CacheDir | Out-Null
    Set-Content -Path $LastBoxFile -Value $box -Encoding ASCII
} catch {}

$backend = "http://${box}:$BackendPort"
$rc = Start-LocalStaticServer $backend
exit $rc
