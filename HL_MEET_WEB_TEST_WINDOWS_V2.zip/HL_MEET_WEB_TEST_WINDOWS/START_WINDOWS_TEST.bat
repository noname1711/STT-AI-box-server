@echo off
setlocal
cd /d "%~dp0"
title HL Meet Web Test
chcp 65001 >nul 2>&1

echo ================================================
echo           HL MEET - WINDOWS WEB TEST V2
echo ================================================
echo.
echo 1. Keep this Windows laptop on the SAME Wi-Fi/LAN as the AI Box.
echo 2. This launcher will find the AI Box automatically on the real Windows LAN.
echo 3. Your browser will open at http://localhost:8000.
echo.
echo Do not close this window while testing.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-test-server.ps1"
set RC=%ERRORLEVEL%

echo.
if not "%RC%"=="0" (
  echo HL Meet launcher stopped with code %RC%.
  echo Read the message above, then press any key.
  pause >nul
)
endlocal
