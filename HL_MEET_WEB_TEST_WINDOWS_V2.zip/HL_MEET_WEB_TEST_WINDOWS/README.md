# HL Meet Windows Web Test V2

For a normal Windows 10/11 tester:

1. Extract the ZIP.
2. Put the Windows laptop on the same Wi-Fi/LAN as the HL Meet AI Box.
3. Double-click `START_WINDOWS_TEST.bat`.
4. Wait for the browser to open at `http://localhost:8000`.
5. When the page shows **Connected**, click **Start microphone**.
6. Allow microphone access if prompted.

No Python, SSH, nmap, curl, Node.js, or manual PowerShell commands are required.

## V2 network-discovery fix

The first Windows launcher assumed every private LAN was `/24`. That can miss a
box on the same real subnet, for example Windows `192.168.1.x/23` with the AI
Box at `192.168.0.x`.

V2:

- prioritizes the Windows interface that has the default gateway;
- reads the actual IPv4 `PrefixLength` from Windows;
- checks the Windows neighbor/ARP table first;
- scans the actual subnet up to `/20` in bounded batches;
- avoids scanning virtual no-gateway adapters when a routed LAN is available;
- still tries `meeting-server.local` and the last confirmed AI Box IP first;
- validates `/api/health` before selecting a device.

The browser frontend remains served only on `127.0.0.1:8000`.
